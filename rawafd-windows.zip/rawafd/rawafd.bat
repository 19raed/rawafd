@echo off
title rawafd
set "URL=https://scratch.mit.edu/studios/51576954"
(where msedge >nul 2>&1) && (start "" msedge --app="%URL%" --new-window & exit /b)
(where chrome >nul 2>&1) && (start "" chrome --app="%URL%" --new-window & exit /b)
start "" "%URL%"
