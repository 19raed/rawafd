Set ws = CreateObject("WScript.Shell")
Set sc = ws.CreateShortcut(ws.SpecialFolders("Desktop") & "\rawafd.lnk")
sc.TargetPath = ws.CurrentDirectory & "\rawafd.bat"
sc.WorkingDirectory = ws.CurrentDirectory
sc.IconLocation = ws.CurrentDirectory & "\icon.ico"
sc.Description = "rawafd - WebToApp"
sc.Save
WScript.Echo "桌面快捷方式已创建！"
