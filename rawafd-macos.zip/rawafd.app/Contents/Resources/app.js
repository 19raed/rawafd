ObjC.import('Cocoa');
ObjC.import('WebKit');

(function () {
  var env = $.NSProcessInfo.processInfo.environment;
  function envStr(key) { var v = env.objectForKey(key); return v ? v.js : ''; }
  var url = envStr('WTA_URL');
  var name = envStr('WTA_NAME') || 'App';
  var iconPath = envStr('WTA_ICON');
  if (!/^https:\/\//i.test(url)) {
    // App Transport Security blocks plain-http loads inside WKWebView; exit
    // non-zero so the shell launcher falls back to browser app mode.
    throw new Error('WTA: embedded WebView requires an https target');
  }
  var app = $.NSApplication.sharedApplication;
  app.setActivationPolicy(0); // regular app: own dock icon + menu bar presence
  app.activateIgnoringOtherApps(true);
  if (iconPath) {
    var img = $.NSImage.alloc.initWithContentsOfFile(iconPath);
    if (img && !img.isNil()) { app.setApplicationIconImage(img); }
  }
  var W = 1280;
  var H = 800;
  var frame = $.NSMakeRect(0, 0, W, H);
  var win = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(frame, 15, 2, false);
  win.setTitle(name);
  var screen = $.NSScreen.mainScreen.frame;
  var x = screen.origin.x + (screen.size.width - W) / 2;
  var y = screen.origin.y + (screen.size.height - H) / 2;
  win.setFrameDisplay($.NSMakeRect(x, y, W, H), true);
  var wv = $.WKWebView.alloc.initWithFrame(frame);
  win.contentView = wv;
  // Quit the whole app when the window closes. NSWindow does not retain its
  // delegate, so the instance must stay alive in this scope while run() spins.
  ObjC.registerSubclass({
    name: 'WTALauncherDelegate',
    methods: {
      'windowWillClose:': {
        types: ['void', ['id']],
        implementation: function () { $.NSApp.terminate(null); }
      }
    }
  });
  var delegate = $.WTALauncherDelegate.alloc.init;
  win.setDelegate(delegate);
  wv.loadRequest($.NSURLRequest.requestWithURL($.NSURL.URLWithString(url)));
  win.makeKeyAndOrderFront(null);
  app.run();
})();
