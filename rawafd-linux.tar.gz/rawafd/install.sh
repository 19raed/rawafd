#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/.local/share/icons"
mkdir -p "$HOME/.local/share/applications"
cp "$DIR/icon.png" "$HOME/.local/share/icons/rawafd.png" 2>/dev/null
cp "$DIR/rawafd.desktop" "$HOME/.local/share/applications/"
echo "✓ rawafd 已安装到应用菜单"
